package com.example.myapplication.helper;

public class urls {
    public static final String URL_ROOT = "http://10.0.0.1/user/api.php?action=";
    public static final String URL_REGISTER = URL_ROOT + "signup";
    public static final String URL_LOGIN = URL_ROOT + "login";
}
